import { queryGameServerInfo } from "steam-server-query";
import { createRouter } from 'next-connect';
import bodyParser from 'body-parser';
import fs from "fs";
import { query } from "../../../lib/db";

const router = createRouter();

router.use(bodyParser.json());

// switchDatabase('UXCMS');

router.post(async (req, res) => {
    try {
        let { servers } = req.body;
        // console.log('Request received with servers:', servers);

        console.log('Performing database query...');
        const results = await query("SELECT * FROM ux_servers");
        console.log('Database query results:', results);

        console.log('я тут 2');
        if (!servers) {
            return res.status(400).json({
                error: 'there is no list of servers, check the server submission'
            });
        }
    
        const serverPromises = servers.map(async elem => {
            try {
                const serverInfo = await queryGameServerInfo(elem.ip, 3, 10000);
                if (elem.customName === '') {
                    elem.customName = serverInfo.name;
                }
                
                elem.players = serverInfo.players;
                elem.maxPlayer = serverInfo.maxPlayers;
                elem.map = serverInfo.map;
                
    
                if (fs.existsSync(`./static/maps/${serverInfo.map}.png`)) {
                    elem.imageNameMap = `/static/maps/${serverInfo.map}.png`;
                }
                else {
                    elem.imageNameMap = 'https://placehold.co/240x206';
                }
    
                return elem;
            } catch (error) {
                console.error(`Error querying server ${elem.ip}:`, error);
                return { ...elem, error: `Error querying server ${elem.ip}` };
            }
        });
    
    
        const resolvedServers = await Promise.all(serverPromises);
    
        res.status(200).json(results);
    } catch (error) {
        console.error(error);
        res.status(500).json(error);
    }
    
});

export default router.handler();