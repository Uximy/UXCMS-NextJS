import { queryGameServerInfo } from "steam-server-query";
import { createRouter } from 'next-connect';
import bodyParser from 'body-parser';

const router = createRouter();

router.use(bodyParser.json());

router.post(async (req, res) => {
    try {
        let { servers } = req.body;

        if (!servers) {
            return res.status(400).json({ error: 'there is no list of servers, check the server submission' });
        }

        const serverPromises = servers.map(async elem => {
            try {
                const serverInfo = await queryGameServerInfo(elem.ip, 3, 10000);

                return serverInfo.players;
            } catch (error) {
                console.error(`Error querying server ${elem.ip}:`, error);
                return { ...elem, error: `Error querying server ${elem.ip}` };
            }
        });

        let resolvedServers = await Promise.all(serverPromises);
        resolvedServers = resolvedServers.reduce((a, b) => {
            return a + b;
        })

        res.status(200).json(resolvedServers);
    } catch (error) {
        console.error(error);
        res.status(400).send('Error: ', error);
    }
    
});

export default router.handler();