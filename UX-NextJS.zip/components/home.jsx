import Image from "next/image";
import Link from "next/link";
import style from "/styles/home.module.css";

function compactServerList(servers) {
  return (
    <div className={style.containerServersTable}>
      <table className={style.servers}>
        <thead>
          <tr>
            <th><i className="material-symbols-rounded">dns</i>Название сервера</th>
            <th><i className="material-symbols-rounded">bring_your_own_ip</i>IP Сервера</th>
            <th><i className="material-symbols-rounded">public</i>Карта</th>
            <th ><i className="material-symbols-rounded">group</i>Количество</th>
          </tr>
        </thead>

        <tbody key={"bodyServers"}>
          {servers.map(({ icon, customServerName, ip, map, players, maxPlayer, key }) => (
            <tr>
              <td key={key} className={style.serverName}>
                <Image
                  src={icon}
                  width={23}
                  height={23}
                  priority
                  alt="game"
                />
                {customServerName}
              </td>
              <td key={key} ><Link className={style.connect} href={`steam://connect/${ip}`}>{ip}</Link></td>
              <td key={key} >{map}</td>
              <td key={key} ><span className={style.players}>{players} / {maxPlayer}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function serverListCards(servers) {
  return (
    <div className={style.containerServers}> 
          {servers.map(({ icon, customServerName, ip, map, imageNameMap, players, maxPlayer, key }) => (
            <div className={style.card}>
              <img
                src={imageNameMap}
                alt={map}
                className={style.maps}
              />
              <div className={style.cardDown}>
                <span className={style.title}>{customServerName}</span>
                <div className={style.lineCard}></div>
                <div>
                  {/* <span>{map}</span> */}
                  <span className={style.players}>{players} / {maxPlayer}</span>
                  <Link className={style.connect} href={`steam://connect/${ip}`}><i className="fa-regular fa-circle-play"></i></Link>
                </div>
              </div>
            </div>
          ))}
      </div>
  )
}

export default function Home(servers) {
  console.log(servers.element);
  let toggleServerList = true;
  return (
    <main className={style.main}>
      {toggleServerList ? serverListCards(servers.element) : compactServerList(servers.element)}
    </main >
  );
}