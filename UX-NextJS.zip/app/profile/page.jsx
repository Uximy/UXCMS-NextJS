import Link from "next/link";
import Style from "/styles/test.module.css";

export default function Test(){
    return (
        <div className={Style.test}>
            профиль пользователя
        </div>
    )
}