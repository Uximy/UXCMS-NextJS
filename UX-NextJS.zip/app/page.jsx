"use client";

import Home from "/components/home";
import { useState, useEffect } from "react";
import axios from "axios";
import serversList from "/serversList.json";


export default function Index() {
    const [servers, setServers] = useState([]);


    useEffect(() => {
        async function fetchServers() {
            try {
                const res = await axios.post('/api/servers',
                    {
                        servers: serversList.servers
                    },
                    {
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }
                );
                console.log(res.data);
                setServers(res.data);
            } catch (error) {
                console.error('Error fetching Steam profile:', error);
            }
            console.log('обновил сервера');
        }

        fetchServers();

        const interval = setInterval(fetchServers, 600000);
        return () => clearInterval(interval);
    }, []);

    return (
        <Home element={servers} />
    );
}
